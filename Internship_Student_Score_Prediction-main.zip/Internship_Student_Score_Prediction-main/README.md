# Internship_Student_Score_Prediction
Task as a part of internship at THE SPARKS FOUNDATION (TSF) under Graduate Rotational Internship Program (GRIP) March 2021.

Task #1: Predict the percentage of a student based on the no. of study hours using Linear Regression.

Dataset Link: http://bit.ly/w-data

Email: aashka.maru@gmail.com
